<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Status Komputer Kiosk')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            
            <?php if(session('success')): ?>
                <div class="mb-4 bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded relative" role="alert">
                    <span class="block sm:inline"><?php echo e(session('success')); ?></span>
                </div>
            <?php endif; ?>
            <?php if(session('error')): ?>
                <div class="mb-4 bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative" role="alert">
                    <span class="block sm:inline"><?php echo e(session('error')); ?></span>
                </div>
            <?php endif; ?>

            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 text-gray-900">
                    <div class="overflow-x-auto">
                        <table class="w-full text-left border-collapse">
                            <thead>
                                <tr class="bg-gray-50 border-b">
                                    <th class="p-3">PC</th>
                                    <th class="p-3">MAC Address</th>
                                    <th class="p-3">Status Saat Ini</th>
                                    <th class="p-3">Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $computers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $komputer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr class="border-b hover:bg-gray-50">
                                    <td class="p-3 font-semibold"><?php echo e($komputer->pc_name); ?></td>
                                    <td class="p-3 font-mono text-sm text-gray-600"><?php echo e($komputer->mac_address); ?></td>
                                    <td class="p-3">
                                        <?php if($komputer->status === \App\Models\Computer::AVAILABLE): ?>
                                            <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
                                                Tersedia
                                            </span>
                                        <?php elseif($komputer->status === \App\Models\Computer::IN_USE): ?>
                                            <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800">
                                                Sedang Dipakai
                                            </span>
                                        <?php elseif($komputer->status === \App\Models\Computer::MAINTENANCE): ?>
                                            <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-red-100 text-red-800">
                                                Maintenance
                                            </span>
                                        <?php endif; ?>
                                    </td>
                                    <td class="p-3">
                                        <?php if($komputer->status === \App\Models\Computer::IN_USE): ?>
                                            <span class="text-gray-400 text-sm italic">Tidak bisa diubah saat dipakai</span>
                                        <?php else: ?>
                                            <form action="<?php echo e(route('admin.komputer.status', $komputer->id)); ?>" method="POST" class="inline">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('PATCH'); ?>
                                                
                                                <?php if($komputer->status === \App\Models\Computer::MAINTENANCE): ?>
                                                    <input type="hidden" name="status" value="<?php echo e(\App\Models\Computer::AVAILABLE); ?>">
                                                    <button type="submit" class="text-green-600 hover:text-green-900 text-sm font-medium underline" onclick="return confirm('Kembalikan PC ini agar bisa dipakai pengunjung lagi?')">
                                                        Tandai Tersedia
                                                    </button>
                                                <?php else: ?>
                                                    <input type="hidden" name="status" value="<?php echo e(\App\Models\Computer::MAINTENANCE); ?>">
                                                    <button type="submit" class="text-red-600 hover:text-red-900 text-sm font-medium underline" onclick="return confirm('Tandai PC ini sebagai maintenance? Pengunjung tidak akan bisa login ke PC ini.')">
                                                        Tandai Maintenance
                                                    </button>
                                                <?php endif; ?>
                                            </form>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\labkom-perpus\resources\views/admin/komputer/index.blade.php ENDPATH**/ ?>